//
//  plant.swift
//  easyPlant
//
//  Created by 김유진 on 2021/04/30.
//

import Foundation
struct Plant {
    var name: String

}

var plants: [Plant] = [
    Plant(name: "산세베리아"),
    Plant(name: "바나나"),
    Plant(name: "백도선"),
    Plant(name: "스킨답서스"),
    Plant(name: "행운목"),
    Plant(name: "만세선인장")
  
]

