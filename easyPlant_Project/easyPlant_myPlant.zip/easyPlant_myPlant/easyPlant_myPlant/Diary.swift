//
//  Diary.swift
//  easyPlant_myPlant
//
//  Created by 현수빈 on 2021/04/30.
//

import Foundation


struct Diary{
    var title : String
    var date : String
    var story : String
    var picture : String
}    


var diarys : [Diary] = [Diary(title: "hello 초록콩",date: "2020-10-31", story: "오늘은 초로콩이 온지 하루 지난날>ㅁ<", picture: "plant1"),
                        Diary(title: "hello 초록콩1", date: "2020-11-30", story: "오늘은 초로콩이 온지 한달 지난날>ㅁ<", picture: "plant1"),
                        Diary(title: "hello 초록콩2",date: "2020-12-30", story: "오늘은 초로콩이 온지 두달 지난날>ㅁ<", picture: "plant1"),Diary(title: "hello 초록콩",date: "2020-10-31", story: "오늘은 초로콩이 온지 하루 지난날>ㅁ<", picture: "plant1"),
                        Diary(title: "hello 초록콩1", date: "2020-11-30", story: "오늘은 초로콩이 온지 한달 지난날>ㅁ<", picture: "plant1"),
                        Diary(title: "hello 초록콩2",date: "2020-12-30", story: "오늘은 초로콩이 온지 두달 지난날>ㅁ<", picture: "plant1"),
                        Diary(title: "hello 초록콩",date: "2020-10-31", story: "오늘은 초로콩이 온지 하루 지난날>ㅁ<", picture: "plant1"),
                                                Diary(title: "hello 초록콩1", date: "2020-11-30", story: "오늘은 초로콩이 온지 한달 지난날>ㅁ<", picture: "plant1"),
                                                Diary(title: "hello 초록콩2",date: "2020-12-30", story: "오늘은 초로콩이 온지 두달 지난날>ㅁ<", picture: "plant1")]
